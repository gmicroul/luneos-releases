# mido Eiskaffee Fixes Manual

This directory contains post-install fixes for the official LuneOS Eiskaffee image on Xiaomi Redmi Note 4X / mido.

It is not a full flashable image and does not replace the official rootfs. It applies only the verified fixes after the official mido image has booted.

## What This Fixes

- Browser video playback audio.
- Default ALSA routing through PulseAudio.
- `audiofocusmanager.service` user creation and boot enablement.
- `umediaserver.service` state directory permissions and boot enablement.
- LS2 permissions required by enactbrowser, app-shell, and chromium audio.
- Surface-manager based VNC service with touch injection.
- Sanity checks for the mido Halium Android LXC layout without replacing Android images.

## Files

- `install-device.sh`
  Device-side installer. Must be run as root.

- `verify-device.sh`
  Device-side verification script. Checks Android LXC, PulseAudio, audiofocusmanager, umediaserver, webapp-mgr, VNC, and default ALSA routing.

- `push-install.sh`
  Host-side push installer. Default target is `root@localhost`.

- `build-ipk.sh`
  Builds an optional IPK package.

- `files/`
  Payload files installed onto the device. Currently contains the VNC service script and systemd unit.

- `build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk`
  Generated optional IPK package.

## Recommended Install Method

If the device is reachable over SSH as root, run this from the host:

```sh
cd /home/user/mido-eiskaffee-fixes
./push-install.sh root@localhost
```

The script copies this directory to `/tmp/mido-eiskaffee-fixes` on the device, then runs:

```sh
/tmp/mido-eiskaffee-fixes/install-device.sh
/tmp/mido-eiskaffee-fixes/verify-device.sh
```

## Deployment Order After Reflashing

After flashing the official Eiskaffee mido package, use this order:

1. Flash the official mido Eiskaffee package and complete the first boot.
2. Confirm root SSH works:

   ```sh
   ssh root@localhost
   ```

3. Confirm the Android LXC path is the mido/halium path:

   ```sh
   lxc-info -n android
   getprop ro.product.device
   ```

   Expected result: the `android` container runs, and the device is `mido`.

4. Run the patch installer from the host:

   ```sh
   cd /home/user/mido-eiskaffee-fixes
   ./push-install.sh root@localhost
   ```

5. Reboot the device, then verify again:

   ```sh
   ssh root@localhost /tmp/mido-eiskaffee-fixes/verify-device.sh
   ```

## Optional IPK Method

Build the IPK:

```sh
cd /home/user/mido-eiskaffee-fixes
./build-ipk.sh
```

Generated file:

```sh
/home/user/mido-eiskaffee-fixes/build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk
```

Install the IPK:

```sh
scp /home/user/mido-eiskaffee-fixes/build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk root@localhost:/tmp/
ssh root@localhost opkg install /tmp/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk
```

The IPK `postinst` runs the same `install-device.sh`. During debugging, prefer `push-install.sh` because its output is easier to inspect.

## Files Modified by the Installer

The installer backs up and modifies these files:

- `/etc/asound.conf`
- `/usr/bin/app-shell/run_app_shell`
- `/usr/share/luna-service2/roles.d/app-shell.role.json`
- `/usr/share/luna-service2/client-permissions.d/app-shell.perm.json`
- `/usr/share/luna-service2/client-permissions.d/com.webos.app.enactbrowser.app.json`
- `/usr/share/luna-service2/roles.d/com.webos.service.audiofocusmanager.role.json`

The installer installs or overwrites these files:

- `/usr/sbin/luneos-surface-vnc`
- `/lib/systemd/system/luneos-surface-vnc.service`

The installer creates or fixes:

- `audio` user
- `/home/audio`
- `/var/lib/ums`
- `/var/lib/ums/conf`

The installer enables or restarts:

- `audiofocusmanager.service`
- `umediaserver.service`
- `webapp-mgr.service`
- `luneos-surface-vnc.service`
- `android-system.service`

## Backups and Rollback

Before the first modification, the installer creates `.mido-fixes.orig` backups for key files. Examples:

```sh
/etc/asound.conf.mido-fixes.orig
/usr/bin/app-shell/run_app_shell.mido-fixes.orig
```

Manual rollback example:

```sh
ssh root@localhost
cp -a /etc/asound.conf.mido-fixes.orig /etc/asound.conf
cp -a /usr/bin/app-shell/run_app_shell.mido-fixes.orig /usr/bin/app-shell/run_app_shell
systemctl daemon-reload
systemctl restart ls-hubd audiofocusmanager umediaserver webapp-mgr
```

VNC rollback:

```sh
systemctl disable --now luneos-surface-vnc.service
rm -f /usr/sbin/luneos-surface-vnc
rm -f /lib/systemd/system/luneos-surface-vnc.service
systemctl daemon-reload
```

## LXC Notes

The correct mido path is:

```sh
/var/lib/lxc/android -> /userdata/luneos-data/luneos-lxc-android
```

The Android container config should keep:

```sh
lxc.net.0.type = none
```

Do not apply a generic LXC bridge/NAT template to this Android container. On mido, RIL, sensors, audio, and related services depend on the Android container sharing the host network and device environment.

Keep these files:

```sh
/var/lib/lxc/android/pre-start.d/10-boot-marker
/var/lib/lxc/android/pre-start.d/30-mount-nothing
/var/lib/lxc/android/pre-start.d/40-rootfs-rw
```

They provide the Android boot marker, remove Android's own `mount_all` actions, and prevent the rootfs from being remounted read-only.

`waydroid-container.service` is not the core path for this mido Halium LXC setup. Do not depend on it for the official mido deployment.

## Verification Commands

Run the full verification:

```sh
ssh root@localhost /tmp/mido-eiskaffee-fixes/verify-device.sh
```

Check services manually:

```sh
ssh root@localhost 'systemctl is-active android-system pulseaudio audiofocusmanager umediaserver webapp-mgr luneos-surface-vnc'
```

Test default ALSA playback through PulseAudio:

```sh
ssh root@localhost 'PULSE_RUNTIME_PATH=/var/run/pulse PULSE_SERVER=unix:/var/run/pulse/native HOME=/home/root aplay -D default /usr/palm/sounds/notification.wav'
```

Inspect browser logs:

```sh
ssh root@localhost 'tail -n 200 /var/volatile/log/com.webos.app.enactbrowser-1'
```

If you see `PulseAudio: Unable to create stream: No such entity` again, first check whether `/etc/asound.conf` contains `device pdefaultapp` again.

## VNC Usage

The VNC service listens on:

```sh
5900
```

Default resolution:

```sh
540x960
```

Service status:

```sh
ssh root@localhost 'systemctl status luneos-surface-vnc.service --no-pager'
```

Logs:

```sh
ssh root@localhost 'journalctl -u luneos-surface-vnc.service -n 80 --no-pager'
```

Touch injection uses `/dev/input/event1`. Wake from black lock screen uses the power key through `/dev/input/event0`.

## Design Principles

This package applies only the minimal verified changes:

- It does not rebuild or replace the official rootfs.
- It does not overwrite Android `android-rootfs.img` or `vendor.img`.
- It does not change the generic LXC networking model.
- It does not merge the host-side `droidspaces` experiments into the official mido deployment.
- JSON permission files are patched structurally with Python, not with fragile string replacement.
