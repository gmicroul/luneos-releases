#!/bin/sh
set -u

fail=0

check() {
    name="$1"
    shift
    if "$@" >/tmp/mido-fixes-check.out 2>&1; then
        printf 'OK   %s\n' "$name"
    else
        printf 'FAIL %s\n' "$name"
        cat /tmp/mido-fixes-check.out
        fail=1
    fi
}

check "android LXC active" systemctl is-active android-system.service
check "pulseaudio active" systemctl is-active pulseaudio.service
check "audiofocusmanager active" systemctl is-active audiofocusmanager.service
check "umediaserver active" systemctl is-active umediaserver.service
check "webapp-mgr active" systemctl is-active webapp-mgr.service
check "surface VNC active" systemctl is-active luneos-surface-vnc.service

check "default ALSA routes to Pulse" sh -c 'grep -A3 "pcm.!default" /etc/asound.conf | grep -q "type pulse" && ! grep -A4 "pcm.!default" /etc/asound.conf | grep -q "pdefaultapp"'
check "Pulse ALSA playback" sh -c 'PULSE_RUNTIME_PATH=/var/run/pulse PULSE_SERVER=unix:/var/run/pulse/native HOME=/home/root aplay -D default /usr/palm/sounds/notification.wav >/dev/null 2>&1'
check "browser app-shell has Pulse env" sh -c 'grep -q "PULSE_SERVER=.*var/run/pulse/native" /usr/bin/app-shell/run_app_shell'
check "android LXC uses host network" sh -c 'grep -q "^lxc.net.0.type = none" /var/lib/lxc/android/config'

printf '\nRecent service state:\n'
systemctl --no-pager --full status audiofocusmanager.service umediaserver.service luneos-surface-vnc.service android-system.service 2>/dev/null | sed -n '1,120p'

exit "$fail"
