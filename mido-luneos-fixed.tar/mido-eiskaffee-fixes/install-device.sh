#!/bin/sh
set -eu

BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STAMP=$(date +%Y%m%d-%H%M%S)

log() {
    printf '%s\n' "$*"
}

backup_file() {
    f="$1"
    if [ -e "$f" ] && [ ! -e "$f.mido-fixes.orig" ]; then
        cp -a "$f" "$f.mido-fixes.orig"
    fi
}

need_root() {
    if [ "$(id -u)" != "0" ]; then
        echo "run as root" >&2
        exit 1
    fi
}

install_payload() {
    log "[1/7] installing payload files"
    install -d /usr/sbin /lib/systemd/system
    install -m 0755 "$BASE_DIR/files/usr/sbin/luneos-surface-vnc" /usr/sbin/luneos-surface-vnc
    install -m 0644 "$BASE_DIR/files/lib/systemd/system/luneos-surface-vnc.service" /lib/systemd/system/luneos-surface-vnc.service
}

fix_asound() {
    log "[2/7] patching /etc/asound.conf"
    backup_file /etc/asound.conf
    python3 - <<'PY'
from pathlib import Path
import re

p = Path("/etc/asound.conf")
text = p.read_text() if p.exists() else ""
text = re.sub(r"(?m)^[ \t]*device[ \t]+pdefaultapp[ \t]*\n", "", text)

if "pcm.!default" not in text:
    text = 'pcm.!default {\n    type pulse\n}\n\n' + text
else:
    def repl(match):
        block = match.group(0)
        if re.search(r"(?m)^[ \t]*type[ \t]+pulse[ \t]*$", block):
            return block
        lines = block.splitlines()
        if len(lines) >= 2:
            lines.insert(1, "    type pulse")
            return "\n".join(lines) + ("\n" if block.endswith("\n") else "")
        return block
    text = re.sub(r"pcm\.!default[ \t]*\{[^}]*\}", repl, text, count=1, flags=re.S)

p.write_text(text)
PY
}

fix_app_shell_env() {
    log "[3/7] patching app-shell Pulse environment"
    f=/usr/bin/app-shell/run_app_shell
    [ -f "$f" ] || return 0
    backup_file "$f"
    python3 - <<'PY'
from pathlib import Path

p = Path("/usr/bin/app-shell/run_app_shell")
text = p.read_text()
wanted = [
    'export HOME="/home/root"',
    'export XDG_RUNTIME_DIR="/tmp/luna-session"',
    'export PULSE_RUNTIME_PATH="/var/run/pulse"',
    'export PULSE_SERVER="unix:/var/run/pulse/native"',
]
lines = text.splitlines()
missing = [line for line in wanted if line not in lines]
if missing:
    insert_at = 1
    for i, line in enumerate(lines):
        if line.startswith("export TMPDIR="):
            insert_at = i + 1
            break
    lines[insert_at:insert_at] = missing
    p.write_text("\n".join(lines) + "\n")
PY
    chmod 0755 "$f"
}

fix_users_and_dirs() {
    log "[4/7] fixing service users and state directories"
    if ! getent passwd audio >/dev/null 2>&1; then
        if getent group audio >/dev/null 2>&1; then
            if getent passwd 1005 >/dev/null 2>&1; then
                useradd -g audio -d /home/audio -s /bin/sh -M audio
            else
                useradd -u 1005 -g audio -d /home/audio -s /bin/sh -M audio
            fi
        else
            groupadd audio
            useradd -u 1005 -g audio -d /home/audio -s /bin/sh -M audio
        fi
    fi
    install -d -o audio -g audio -m 0755 /home/audio
    install -d -o media -g media -m 0755 /var/lib/ums /var/lib/ums/conf
}

patch_ls2_json() {
    log "[5/7] patching LS2 permissions"
    for f in \
        /usr/share/luna-service2/roles.d/app-shell.role.json \
        /usr/share/luna-service2/client-permissions.d/app-shell.perm.json \
        /usr/share/luna-service2/client-permissions.d/com.webos.app.enactbrowser.app.json \
        /usr/share/luna-service2/roles.d/com.webos.service.audiofocusmanager.role.json
    do
        [ -f "$f" ] && backup_file "$f"
    done

    python3 - <<'PY'
from pathlib import Path
import json

def load(path):
    p = Path(path)
    return p, json.loads(p.read_text())

def save(p, data):
    p.write_text(json.dumps(data, indent=4) + "\n")

def add_unique(seq, *items):
    for item in items:
        if item not in seq:
            seq.append(item)

def perm_entry(role, service):
    perms = role.setdefault("permissions", [])
    for item in perms:
        if item.get("service") == service:
            item.setdefault("outbound", [])
            return item
    item = {"service": service, "outbound": []}
    perms.append(item)
    return item

p, role = load("/usr/share/luna-service2/roles.d/app-shell.role.json")
add_unique(role.setdefault("allowedNames", []), "com.webos.app.enactbrowser-*")
add_unique(
    perm_entry(role, "com.webos.app.enactbrowser").setdefault("outbound", []),
    "com.webos.service.audiofocusmanager",
    "com.webos.media",
    "com.webos.service.mediacontroller",
    "com.webos.service.account",
)
add_unique(
    perm_entry(role, "com.webos.chromium.audio-*").setdefault("outbound", []),
    "com.webos.service.audiofocusmanager",
)
add_unique(
    perm_entry(role, "com.webos.app.enactbrowser-*").setdefault("outbound", []),
    "*",
)
save(p, role)

p, perms = load("/usr/share/luna-service2/client-permissions.d/app-shell.perm.json")
add_unique(perms.setdefault("com.webos.app.enactbrowser", []), "audiofocus.operation", "audiofocus.query")
add_unique(perms.setdefault("com.webos.chromium.audio-*", []), "audiofocus.operation", "audiofocus.query")
save(p, perms)

p, perms = load("/usr/share/luna-service2/client-permissions.d/com.webos.app.enactbrowser.app.json")
add_unique(perms.setdefault("com.webos.app.enactbrowser-*", []), "audiofocus.operation", "audiofocus.query")
save(p, perms)

p, role = load("/usr/share/luna-service2/roles.d/com.webos.service.audiofocusmanager.role.json")
outbound = perm_entry(role, "com.webos.service.audiofocusmanager").setdefault("outbound", [])
add_unique(
    outbound,
    "com.webos.service.account",
    "com.webos.chromium.audio-*",
    "com.webos.app.enactbrowser",
    "com.webos.app.enactbrowser-*",
    "com.webos.rm.client.*",
)
save(p, role)
PY
}

check_lxc_android() {
    log "[6/7] checking mido Android LXC deployment"
    if [ ! -L /var/lib/lxc/android ]; then
        log "WARN: /var/lib/lxc/android is not a symlink"
    fi
    if [ ! -d /userdata/luneos-data/luneos-lxc-android ]; then
        log "WARN: missing /userdata/luneos-data/luneos-lxc-android"
    fi
    if [ -f /var/lib/lxc/android/config ] && ! grep -q '^lxc.net.0.type = none' /var/lib/lxc/android/config; then
        log "WARN: android LXC is not configured with shared host networking"
    fi
    for f in \
        /var/lib/lxc/android/pre-start.d/10-boot-marker \
        /var/lib/lxc/android/pre-start.d/30-mount-nothing \
        /var/lib/lxc/android/pre-start.d/40-rootfs-rw
    do
        [ -f "$f" ] || log "WARN: missing $f"
    done
}

restart_services() {
    log "[7/7] reloading services"
    systemctl daemon-reload || true
    systemctl enable audiofocusmanager.service umediaserver.service luneos-surface-vnc.service android-system.service || true
    if command -v ls-control >/dev/null 2>&1; then
        ls-control scan-services || true
    fi
    systemctl restart ls-hubd.service || true
    systemctl reset-failed audiofocusmanager.service umediaserver.service luneos-surface-vnc.service || true
    systemctl restart audiofocusmanager.service || true
    systemctl restart umediaserver.service || true
    systemctl restart webapp-mgr.service || true
    systemctl restart luneos-surface-vnc.service || true
}

need_root
install_payload
fix_asound
fix_app_shell_env
fix_users_and_dirs
patch_ls2_json
check_lxc_android
restart_services

log "done: mido Eiskaffee fixes installed"
