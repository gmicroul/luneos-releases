# mido Eiskaffee 补丁包说明书

这个目录用于在官方 LuneOS Eiskaffee mido 镜像刷完以后，追加安装我们已经验证过的修复。

目标机型是 Xiaomi Redmi Note 4X / mido，系统路径按当前设备的 Halium Android 9 LXC 部署编写。它不是完整刷机包，也不替代官方 rootfs，只做 post-install 修补。

## 包含内容

- 浏览器视频播放声音修复。
- PulseAudio 默认 ALSA 路由修复。
- `audiofocusmanager.service` 用户和开机启用修复。
- `umediaserver.service` 状态目录权限和开机启用修复。
- enactbrowser / app-shell / chromium audio 需要的 LS2 权限补丁。
- 基于 `luna-surfacemanager` 截图和 `/dev/input/event1` 触控注入的 VNC 服务。
- mido Android LXC 关键部署检查，不覆盖 Android 镜像。

## 文件说明

- `install-device.sh`
  设备端安装脚本。需要 root 执行。

- `verify-device.sh`
  设备端验证脚本。检查 Android LXC、PulseAudio、audiofocusmanager、umediaserver、webapp-mgr、VNC 和 ALSA 默认路由。

- `push-install.sh`
  本机推送安装脚本。默认目标是 `root@localhost`。

- `build-ipk.sh`
  生成可选 IPK 包。

- `files/`
  要安装到设备的 payload，目前包含 VNC 服务脚本和 systemd unit。

- `build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk`
  已生成的可选 IPK。

## 推荐使用方式

当前设备已经能 SSH 到 root 的情况下，推荐直接从本机推送执行：

```sh
cd /home/user/mido-eiskaffee-fixes
./push-install.sh root@localhost
```

脚本会复制整个目录到设备 `/tmp/mido-eiskaffee-fixes`，然后执行：

```sh
/tmp/mido-eiskaffee-fixes/install-device.sh
/tmp/mido-eiskaffee-fixes/verify-device.sh
```

## 刷机后部署顺序

如果以后重新刷官方 Eiskaffee mido 包，我建议按这个顺序：

1. 先刷官方 mido Eiskaffee 包并完成首次启动。
2. 确认能通过 SSH 进入设备：

   ```sh
   ssh root@localhost
   ```

3. 确认 Android LXC 是当前 mido/halium 路径：

   ```sh
   lxc-info -n android
   getprop ro.product.device
   ```

   期望 `android` 容器能运行，设备是 `mido`。

4. 回到本机执行补丁安装：

   ```sh
   cd /home/user/mido-eiskaffee-fixes
   ./push-install.sh root@localhost
   ```

5. 重启设备后再次验证：

   ```sh
   ssh root@localhost /tmp/mido-eiskaffee-fixes/verify-device.sh
   ```

## 可选 IPK 方式

生成 IPK：

```sh
cd /home/user/mido-eiskaffee-fixes
./build-ipk.sh
```

生成文件：

```sh
/home/user/mido-eiskaffee-fixes/build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk
```

安装 IPK 示例：

```sh
scp /home/user/mido-eiskaffee-fixes/build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk root@localhost:/tmp/
ssh root@localhost opkg install /tmp/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk
```

IPK 的 `postinst` 会调用同一个 `install-device.sh`。调试阶段优先用 `push-install.sh`，因为失败时更容易看输出。

## 安装脚本会改哪些地方

安装脚本会备份并修改这些文件：

- `/etc/asound.conf`
- `/usr/bin/app-shell/run_app_shell`
- `/usr/share/luna-service2/roles.d/app-shell.role.json`
- `/usr/share/luna-service2/client-permissions.d/app-shell.perm.json`
- `/usr/share/luna-service2/client-permissions.d/com.webos.app.enactbrowser.app.json`
- `/usr/share/luna-service2/roles.d/com.webos.service.audiofocusmanager.role.json`

安装脚本会安装或覆盖这些文件：

- `/usr/sbin/luneos-surface-vnc`
- `/lib/systemd/system/luneos-surface-vnc.service`

安装脚本会创建或修复：

- `audio` 用户
- `/home/audio`
- `/var/lib/ums`
- `/var/lib/ums/conf`

安装脚本会启用或重启：

- `audiofocusmanager.service`
- `umediaserver.service`
- `webapp-mgr.service`
- `luneos-surface-vnc.service`
- `android-system.service`

## 备份和回滚

首次修改前，脚本会给关键文件生成 `.mido-fixes.orig` 备份。例如：

```sh
/etc/asound.conf.mido-fixes.orig
/usr/bin/app-shell/run_app_shell.mido-fixes.orig
```

手动回滚示例：

```sh
ssh root@localhost
cp -a /etc/asound.conf.mido-fixes.orig /etc/asound.conf
cp -a /usr/bin/app-shell/run_app_shell.mido-fixes.orig /usr/bin/app-shell/run_app_shell
systemctl daemon-reload
systemctl restart ls-hubd audiofocusmanager umediaserver webapp-mgr
```

VNC 回滚：

```sh
systemctl disable --now luneos-surface-vnc.service
rm -f /usr/sbin/luneos-surface-vnc
rm -f /lib/systemd/system/luneos-surface-vnc.service
systemctl daemon-reload
```

## LXC 注意事项

mido 当前正确路径是：

```sh
/var/lib/lxc/android -> /userdata/luneos-data/luneos-lxc-android
```

Android 容器配置里应保留：

```sh
lxc.net.0.type = none
```

不要把普通 LXC bridge/NAT 模板套进这个 Android 容器。mido 的 RIL、传感器、音频等服务依赖 Android 容器和宿主共享网络/设备环境。

这些文件也要保留：

```sh
/var/lib/lxc/android/pre-start.d/10-boot-marker
/var/lib/lxc/android/pre-start.d/30-mount-nothing
/var/lib/lxc/android/pre-start.d/40-rootfs-rw
```

它们负责 Android boot 标记、禁用 Android 自己的 `mount_all`、避免 rootfs 被重新挂成只读。

`waydroid-container.service` 当前不是这套 mido Halium LXC 的核心路径。正式部署不要依赖它。

## 验证命令

一键验证：

```sh
ssh root@localhost /tmp/mido-eiskaffee-fixes/verify-device.sh
```

手动查看服务：

```sh
ssh root@localhost 'systemctl is-active android-system pulseaudio audiofocusmanager umediaserver webapp-mgr luneos-surface-vnc'
```

测试默认 ALSA 到 PulseAudio：

```sh
ssh root@localhost 'PULSE_RUNTIME_PATH=/var/run/pulse PULSE_SERVER=unix:/var/run/pulse/native HOME=/home/root aplay -D default /usr/palm/sounds/notification.wav'
```

查看浏览器日志：

```sh
ssh root@localhost 'tail -n 200 /var/volatile/log/com.webos.app.enactbrowser-1'
```

如果再次看到类似 `PulseAudio: Unable to create stream: No such entity`，优先检查 `/etc/asound.conf` 里是否又出现了 `device pdefaultapp`。

## VNC 使用

服务监听端口：

```sh
5900
```

默认分辨率：

```sh
540x960
```

服务状态：

```sh
ssh root@localhost 'systemctl status luneos-surface-vnc.service --no-pager'
```

日志：

```sh
ssh root@localhost 'journalctl -u luneos-surface-vnc.service -n 80 --no-pager'
```

VNC 触控使用 `/dev/input/event1`，唤醒黑屏锁屏时使用 `/dev/input/event0` 的 power key。

## 设计原则

这个补丁包只做已验证的最小修改：

- 不重打官方 rootfs。
- 不覆盖 Android `android-rootfs.img` 或 `vendor.img`。
- 不改通用 LXC 网络模式。
- 不把本机 `droidspaces` 实验配置合入 mido 正式部署。
- 所有 JSON 权限补丁用 Python 按结构修改，避免靠字符串替换破坏 JSON。
