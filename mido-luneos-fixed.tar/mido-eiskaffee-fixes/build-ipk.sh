#!/bin/sh
set -eu

BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD="$BASE_DIR/build/ipk"
OUT="$BASE_DIR/build/org.webosports.mido-eiskaffee-fixes_0.1.0_all.ipk"

rm -rf "$BUILD"
mkdir -p "$BUILD/CONTROL" "$BUILD/usr/share/mido-eiskaffee-fixes"
cp -a "$BASE_DIR/files" "$BUILD/usr/share/mido-eiskaffee-fixes/"
cp "$BASE_DIR/install-device.sh" "$BUILD/usr/share/mido-eiskaffee-fixes/install-device.sh"
cp "$BASE_DIR/verify-device.sh" "$BUILD/usr/share/mido-eiskaffee-fixes/verify-device.sh"
chmod 0755 "$BUILD/usr/share/mido-eiskaffee-fixes/install-device.sh" "$BUILD/usr/share/mido-eiskaffee-fixes/verify-device.sh"

cat > "$BUILD/CONTROL/control" <<'EOF'
Package: org.webosports.mido-eiskaffee-fixes
Version: 0.1.0
Architecture: all
Maintainer: local
Description: Post-install fixes for LuneOS Eiskaffee on mido
Priority: optional
Section: misc
EOF

cat > "$BUILD/CONTROL/postinst" <<'EOF'
#!/bin/sh
set -e
/usr/share/mido-eiskaffee-fixes/install-device.sh
exit 0
EOF
chmod 0755 "$BUILD/CONTROL/postinst"

cd "$BUILD"
tar --format=gnu -czf "$BASE_DIR/build/control.tar.gz" -C "$BUILD/CONTROL" .
tar --format=gnu -czf "$BASE_DIR/build/data.tar.gz" -C "$BUILD" usr
printf '2.0\n' > "$BASE_DIR/build/debian-binary"
cd "$BASE_DIR/build"
ar r "$OUT" debian-binary control.tar.gz data.tar.gz >/dev/null
printf '%s\n' "$OUT"
