#!/bin/sh
set -eu

HOST=${1:-root@localhost}
REMOTE_DIR=/tmp/mido-eiskaffee-fixes
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

ssh "$HOST" "rm -rf '$REMOTE_DIR' && mkdir -p '$REMOTE_DIR'"
tar -C "$BASE_DIR" -czf - . | ssh "$HOST" "tar -C '$REMOTE_DIR' -xzf -"
ssh "$HOST" "chmod +x '$REMOTE_DIR/install-device.sh' '$REMOTE_DIR/verify-device.sh' && '$REMOTE_DIR/install-device.sh'"
ssh "$HOST" "'$REMOTE_DIR/verify-device.sh'"
